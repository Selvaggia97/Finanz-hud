@echo off
chcp 65001 > nul
echo ===================================================
echo   Starte dein Finanz-HUD am rechten Bildschirmrand...
echo ===================================================
echo.

python "%~dp0finanzen.py"

if %errorlevel% neq 0 (
    echo.
    echo [FEHLER] Das Programm konnte nicht gestartet werden.
    echo.
    echo Moegliche Ursachen:
    echo 1. Python ist nicht auf deinem PC installiert.
    echo    Gehe auf https://www.python.org und lade es herunter.
    echo 2. Bei der Python-Installation wurde das Haeckchen bei 
    echo    "Add python.exe to PATH" vergessen.
    echo.
    echo Bitte ueberpruefe die Installation und versuche es erneut.
    echo.
    pause
)
