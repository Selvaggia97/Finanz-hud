import tkinter as tk
from tkinter import ttk, messagebox
import json
import os
import calendar
from datetime import datetime

DATA_FILE = "finanzen_daten.json"
T_COLOR = "#abcdef"  # Transparent color key for Windows
HUD_BG = "#1e222b"   # Dark background
HUD_ITEM_BG = "#252936" # Slightly lighter dark for components
ACCENT = "#8be9fd"   # Beautiful cyan/blue accent

class DesktopHUD:
    def __init__(self, root):
        self.root = root
        self.root.withdraw() # Hide the main root window
        
        # Load data and configuration
        self.data = self.load_data()
        self.config = self.data.get("config", {
            "fixkosten": 0.0,
            "alpha": 0.90,
            "hud_height": 650,
            "hud_y": 150
        })
        
        self.hud_width = 300
        self.is_expanded = False
        self.toggle_btn_size = 40
        
        # Get screen dimensions
        self.screen_w = self.root.winfo_screenwidth()
        self.screen_h = self.root.winfo_screenheight()
        self.collapsed_y = self.config.get("hud_y", 150)
        
        # --- 1. THE TOGGLE WINDOW (ROUND DESKTOP BUTTON) ---
        self.toggle_win = tk.Toplevel(self.root)
        self.toggle_win.overrideredirect(True)
        self.toggle_win.config(bg=T_COLOR)
        self.toggle_win.attributes("-transparentcolor", T_COLOR)
        self.toggle_win.attributes("-topmost", False) # Sinks behind normal windows!
        
        # Position button at the right edge
        self.toggle_win.geometry("{}x{}+{}+{}".format(
            self.toggle_btn_size, self.toggle_btn_size, 
            self.screen_w - self.toggle_btn_size - 10, self.collapsed_y
        ))

        self.draw_toggle_button("closed")
        
        # --- 2. THE HUD WINDOW (SLIDE-OUT PANEL) ---
        self.hud_win = tk.Toplevel(self.root)
        self.hud_win.overrideredirect(True)
        self.hud_win.attributes("-topmost", True) # Stays on top only when opened for interaction
        self.hud_win.attributes("-alpha", self.config.get("alpha", 0.90))
        self.hud_win.config(bg=HUD_BG)
        self.hud_win.withdraw() # Initially hidden
        
        self.setup_hud_ui()
        self.refresh_hud_data()

    def load_data(self):
        default_data = {"transactions": [], "config": {"fixkosten": 0.0, "alpha": 0.90, "hud_height": 650, "hud_y": 150}}
        if os.path.exists(DATA_FILE):
            try:
                with open(DATA_FILE, "r", encoding="utf-8") as f:
                    content = json.load(f)
                    if isinstance(content, list):
                        return {"transactions": content, "config": default_data["config"]}
                    return content
            except:
                return default_data
        return default_data

    def save_data(self):
        self.data["config"] = self.config
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=4)

    def draw_toggle_button(self, state="closed"):
        if hasattr(self, 'canvas_toggle'):
            self.canvas_toggle.delete("all")
        else:
            self.canvas_toggle = tk.Canvas(self.toggle_win, width=self.toggle_btn_size, height=self.toggle_btn_size, bg=T_COLOR, highlightthickness=0)
            self.canvas_toggle.pack()
            self.canvas_toggle.bind("<Button-1>", lambda e: self.toggle_hud())

        if state == "closed":
            # Round button with Euro symbol
            self.canvas_toggle.create_oval(2, 2, 38, 38, fill=ACCENT, outline="", width=0)
            self.canvas_toggle.create_text(20, 20, text="€", fill=HUD_BG, font=("Arial", 14, "bold"))
        else:
            # Side bar indicator when HUD is open
            h = self.config.get("hud_height", 650)
            self.canvas_toggle.create_rectangle(15, 0, 40, h, fill=ACCENT, outline="", width=0)
            self.canvas_toggle.create_text(27, h // 2, text=">", fill=HUD_BG, font=("Arial", 14, "bold"))

    def setup_hud_ui(self):
        main_frame = tk.Frame(self.hud_win, bg=HUD_BG, bd=0)
        main_frame.pack(fill="both", expand=True)
        
        # Top Bar (Title & Settings Icon)
        top_bar = tk.Frame(main_frame, bg=HUD_BG)
        top_bar.pack(fill="x", pady=(8,0), padx=10)
        
        lbl_title = tk.Label(top_bar, text="FINANZ HUD", font=("Arial", 12, "bold"), bg=HUD_BG, fg=ACCENT)
        lbl_title.pack(side="left")
        
        btn_settings = tk.Button(top_bar, text="⚙", font=("Arial", 12), bg=HUD_BG, fg="#8a92a6", bd=0, 
                                 activebackground=HUD_BG, activeforeground="#ffffff", command=self.open_detail_window)
        btn_settings.pack(side="right")
        
        # Budget Summary Display
        budget_frame = tk.Frame(main_frame, bg=HUD_ITEM_BG, bd=1, relief="solid")
        budget_frame.pack(fill="x", padx=10, pady=8)
        
        self.lbl_day_budget = tk.Label(budget_frame, text="Heute: 0.00 €", font=("Arial", 16, "bold"), bg=HUD_ITEM_BG, fg="#50fa7b")
        self.lbl_day_budget.pack(pady=6)
        
        self.lbl_month_remain = tk.Label(budget_frame, text="Rest im Monat: 0.00 €", font=("Arial", 10), bg=HUD_ITEM_BG, fg="#ffb86c")
        self.lbl_month_remain.pack(pady=2)
        
        self.lbl_days_left = tk.Label(budget_frame, text="Tage verbleibend: 0", font=("Arial", 9, "italic"), bg=HUD_ITEM_BG, fg="#8a92a6")
        self.lbl_days_left.pack(pady=2)

        # Quick Entry Panel
        input_frame = tk.Frame(main_frame, bg=HUD_BG)
        input_frame.pack(fill="x", padx=10, pady=8)
        
        tk.Label(input_frame, text="Schnelleintrag:", font=("Arial", 9, "bold"), bg=HUD_BG, fg="#ffffff").pack(anchor="w", pady=(0,2))
        
        entry_row = tk.Frame(input_frame, bg=HUD_BG)
        entry_row.pack(fill="x", pady=2)
        
        self.hud_amount = ttk.Entry(entry_row, width=10, font=("Arial", 10))
        self.hud_amount.pack(side="left", padx=(0,4))
        self.hud_amount.insert(0, "Betrag")
        self.hud_amount.bind("<FocusIn>", lambda e: self.hud_amount.delete(0, tk.END) if self.hud_amount.get()=="Betrag" else None)
        
        self.hud_type = ttk.Combobox(entry_row, values=["- Ausgabe", "+ Einnahme"], width=10, state="readonly")
        self.hud_type.set("- Ausgabe")
        self.hud_type.pack(side="left")
        
        self.hud_cat = ttk.Combobox(input_frame, values=["Lebensmittel", "Freizeit", "Wohnen", "Auto/ÖPNV", "Gehalt", "Sonstiges"], state="readonly")
        self.hud_cat.set("Lebensmittel")
        self.hud_cat.pack(fill="x", pady=4)
        
        btn_quick_add = tk.Button(input_frame, text="Buchen", bg=ACCENT, fg=HUD_BG, font=("Arial", 9, "bold"), bd=0, command=self.quick_add)
        btn_quick_add.pack(fill="x", pady=4)

        # Mini Expense Distribution Chart
        tk.Label(main_frame, text="Ausgaben-Verteilung:", font=("Arial", 9, "bold"), bg=HUD_BG, fg="#ffffff").pack(anchor="w", padx=10, pady=(8,0))
        self.canvas_chart = tk.Canvas(main_frame, width=260, height=180, bg=HUD_ITEM_BG, highlightthickness=0)
        self.canvas_chart.pack(padx=10, pady=5, fill="both", expand=True)

    def toggle_hud(self):
        h = self.config.get("hud_height", 650)
        y = self.config.get("hud_y", 150)
        
        if self.is_expanded:
            # Hide the HUD
            self.hud_win.withdraw()
            # Restore the desktop floating round button
            self.toggle_win.attributes("-topmost", False)
            self.toggle_win.geometry("{}x{}+{}+{}".format(
                self.toggle_btn_size, self.toggle_btn_size,
                self.screen_w - self.toggle_btn_size - 10, self.collapsed_y
            ))
            self.draw_toggle_button("closed")
            self.is_expanded = False
        else:
            # Display the HUD sliding out from the right side
            self.hud_win.geometry("{}x{}+{}+{}".format(self.hud_width, h, self.screen_w - self.hud_width, y))
            self.hud_win.deiconify()
            self.hud_win.attributes("-topmost", True)
            
            # Reposition the button window to act as a closing tab attached to the HUD's left edge
            self.toggle_win.attributes("-topmost", True)
            self.toggle_win.geometry("{}x{}+{}+{}".format(
                self.toggle_btn_size, h,
                self.screen_w - self.hud_width - self.toggle_btn_size + 15, y
            ))
            self.draw_toggle_button("open")
            self.refresh_hud_data()
            self.is_expanded = True

    def refresh_hud_data(self):
        now = datetime.now()
        total_days = calendar.monthrange(now.year, now.month)[1]
        days_remaining = total_days - now.day + 1
        current_month_str = now.strftime(".%m.%Y")
        
        monat_einnahmen = 0.0
        monat_ausgaben = 0.0
        cat_sums = {}

        for t in self.data.get("transactions", []):
            if current_month_str in t["date"]:
                amt = t["amount"]
                if "Einnahme" in t["type"]:
                    monat_einnahmen += amt
                else:
                    monat_ausgaben += amt
                    cat = t["category"]
                    cat_sums[cat] = cat_sums.get(cat, 0.0) + amt

        fixkosten = float(self.config.get("fixkosten", 0.0))
        verbleibend_monat = monat_einnahmen - monat_ausgaben - fixkosten
        tages_budget = verbleibend_monat / days_remaining if days_remaining > 0 else 0.0
        
        self.lbl_day_budget.config(text="Heute: {:.2f} €".format(max(0.0, tages_budget)) if tages_budget > 0 else "Heute: 0.00 €")
        self.lbl_month_remain.config(text="Rest im Monat: {:.2f} €".format(verbleibend_monat))
        self.lbl_days_left.config(text="Verbleibende Tage: {} von {}".format(days_remaining, total_days))
        
        if tages_budget < 5.0:
            self.lbl_day_budget.config(fg="#ff5555")
        else:
            self.lbl_day_budget.config(fg="#50fa7b")
            
        self.draw_chart(cat_sums)

    def draw_chart(self, cat_sums):
        self.canvas_chart.delete("all")
        if not cat_sums:
            self.canvas_chart.create_text(130, 90, text="Keine Ausgaben diesen Monat", fill="#8a92a6", font=("Arial", 9))
            return
        
        max_val = max(cat_sums.values())
        y_offset = 20
        colors = ["#ff5555", "#ffb86c", "#f1fa8c", "#bd93f9", "#ff79c6", ACCENT]
        
        for i, (cat, val) in enumerate(cat_sums.items()):
            if i > 5: break
            bar_width = int((val / max_val) * 140) if max_val > 0 else 0
            self.canvas_chart.create_text(10, y_offset, text=cat[:10], fill="#ffffff", anchor="w", font=("Arial", 8))
            self.canvas_chart.create_rectangle(80, y_offset-6, 80+bar_width, y_offset+6, fill=colors[i%len(colors)], width=0)
            self.canvas_chart.create_text(230, y_offset, text="{:.0f}€".format(val), fill="#8a92a6", anchor="w", font=("Arial", 8))
            y_offset += 25

    def quick_add(self):
        try:
            amt_str = self.hud_amount.get().replace(",", ".")
            amount = round(float(amt_str), 2)
            if amount <= 0: raise ValueError
        except ValueError:
            messagebox.showerror("Fehler", "Bitte gültigen Betrag eingeben.")
            return
        
        new_trans = {
            "date": datetime.now().strftime("%d.%m.%Y %H:%M"),
            "type": self.hud_type.get(),
            "category": self.hud_cat.get(),
            "amount": amount,
            "desc": "HUD Schnellbuchung"
        }
        
        self.data.setdefault("transactions", []).insert(0, new_trans)
        self.save_data()
        self.refresh_hud_data()
        self.hud_amount.delete(0, tk.END)
        self.hud_amount.insert(0, "Betrag")
        self.hud_win.focus()

    def open_detail_window(self):
        if hasattr(self, 'detail_win') and self.detail_win.winfo_exists():
            self.detail_win.lift()
            return
            
        self.detail_win = tk.Toplevel(self.root)
        self.detail_win.title("Detailansicht & Einstellungen")
        self.detail_win.geometry("750x650")
        self.detail_win.configure(bg="#f0f2f5")
        
        # --- SETTINGS FRAME ---
        settings_lf = tk.LabelFrame(self.detail_win, text=" HUD Einstellungen & Fixkosten ", bg="#f0f2f5", font=("Arial", 10, "bold"), padx=10, pady=10)
        settings_lf.pack(fill="x", padx=15, pady=10)
        
        tk.Label(settings_lf, text="Monatliche Fixkosten (€):", bg="#f0f2f5").grid(row=0, column=0, sticky="w", pady=4)
        ent_fix = ttk.Entry(settings_lf, width=10)
        ent_fix.insert(0, str(self.config.get("fixkosten", 0.0)))
        ent_fix.grid(row=0, column=1, padx=5, pady=4)
        
        tk.Label(settings_lf, text="HUD Höhe (Pixel):", bg="#f0f2f5").grid(row=0, column=2, sticky="w", padx=10, pady=4)
        ent_height = ttk.Entry(settings_lf, width=8)
        ent_height.insert(0, str(self.config.get("hud_height", 650)))
        ent_height.grid(row=0, column=3, padx=5, pady=4)
        
        tk.Label(settings_lf, text="Transparenz (0.1 - 1.0):", bg="#f0f2f5").grid(row=1, column=0, sticky="w", pady=4)
        ent_alpha = ttk.Entry(settings_lf, width=10)
        ent_alpha.insert(0, str(self.config.get("alpha", 0.90)))
        ent_alpha.grid(row=1, column=1, padx=5, pady=4)
        
        tk.Label(settings_lf, text="Y-Position (Pixel):", bg="#f0f2f5").grid(row=1, column=2, sticky="w", padx=10, pady=4)
        ent_y = ttk.Entry(settings_lf, width=8)
        ent_y.insert(0, str(self.config.get("hud_y", 150)))
        ent_y.grid(row=1, column=3, padx=5, pady=4)

        def save_settings():
            try:
                self.config["fixkosten"] = round(float(ent_fix.get().replace(",", ".")), 2)
                self.config["hud_height"] = max(300, int(ent_height.get()))
                self.config["hud_y"] = max(0, int(ent_y.get()))
                alpha = float(ent_alpha.get())
                self.config["alpha"] = max(0.2, min(1.0, alpha))
                
                self.save_data()
                self.hud_win.attributes("-alpha", self.config["alpha"])
                self.collapsed_y = self.config["hud_y"]
                
                if not self.is_expanded:
                    self.toggle_win.geometry("{}x{}+{}+{}".format(
                        self.toggle_btn_size, self.toggle_btn_size,
                        self.screen_w - self.toggle_btn_size - 10, self.collapsed_y
                    ))
                else:
                    self.hud_win.geometry("{}x{}+{}+{}".format(self.hud_width, self.config["hud_height"], self.screen_w - self.hud_width, self.config["hud_y"]))
                    self.toggle_win.geometry("{}x{}+{}+{}".format(
                        self.toggle_btn_size, self.config["hud_height"],
                        self.screen_w - self.hud_width - self.toggle_btn_size + 15, self.config["hud_y"]
                    ))
                    self.draw_toggle_button("open")
                
                self.refresh_hud_data()
                messagebox.showinfo("Gespeichert", "Einstellungen erfolgreich übernommen!")
            except ValueError:
                messagebox.showerror("Fehler", "Bitte überprüfe deine Eingaben auf Zahlenwerte.")

        btn_save_settings = ttk.Button(settings_lf, text="Anwenden", command=save_settings)
        btn_save_settings.grid(row=2, column=3, padx=5, pady=8, sticky="e")
        
        btn_auto = ttk.Button(settings_lf, text="Autostart ein/aus", command=self.toggle_autostart)
        btn_auto.grid(row=0, column=4, rowspan=2, padx=20, pady=4)

        # --- TRANSACTION TABLE ---
        table_frame = tk.Frame(self.detail_win)
        table_frame.pack(fill="both", expand=True, padx=15, pady=10)
        
        columns = ("date", "type", "category", "amount", "desc")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings")
        self.tree.heading("date", text="Datum")
        self.tree.heading("type", text="Typ")
        self.tree.heading("category", text="Kategorie")
        self.tree.heading("amount", text="Betrag")
        self.tree.heading("desc", text="Beschreibung")
        
        self.tree.column("date", width=120, anchor="center")
        self.tree.column("type", width=80, anchor="center")
        self.tree.column("category", width=120, anchor="w")
        self.tree.column("amount", width=90, anchor="e")
        self.tree.column("desc", width=260, anchor="w")
        self.tree.pack(side="left", fill="both", expand=True)
        
        scroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        
        def delete_selected():
            sel = self.tree.selection()
            if not sel: return
            idx = self.tree.index(sel[0])
            del self.data["transactions"][idx]
            self.save_data()
            self.refresh_hud_data()
            update_table()
            
        btn_del = ttk.Button(self.detail_win, text="Ausgewählte Buchung löschen", command=delete_selected)
        btn_del.pack(pady=5)
        
        btn_quit = tk.Button(self.detail_win, text="Komplettes Programm beenden", bg="#ff5555", fg="white", font=("Arial", 10, "bold"), command=self.root.quit)
        btn_quit.pack(side="bottom", fill="x", padx=15, pady=10)

        def update_table():
            for item in self.tree.get_children(): self.tree.delete(item)
            for t in self.data.get("transactions", []):
                amt_str = "{}{} {:.2f} €".format('+' if 'Einnahme' in t['type'] else '-', t['amount'])
                self.tree.insert("", tk.END, values=(t["date"], t["type"], t["category"], amt_str, t["desc"]))
        
        update_table()

    def toggle_autostart(self):
        startup_dir = os.path.join(os.getenv('APPDATA'), r'Microsoft\Windows\Start Menu\Programs\Startup')
        shortcut_path = os.path.join(startup_dir, "FinanzManagerHUD.bat")
        current_bat = os.path.abspath("starten.bat")
        
        if os.path.exists(shortcut_path):
            try:
                os.remove(shortcut_path)
                messagebox.showinfo("Autostart", "Autostart wurde erfolgreich deaktiviert.")
            except Exception as e:
                messagebox.showerror("Fehler", "Konnte Datei nicht entfernen: {}".format(e))
        else:
            if not os.path.exists(current_bat):
                try:
                    with open(current_bat, "w", encoding="utf-8") as f:
                        f.write('@echo off\npython "{}"\n'.format(os.path.abspath(__file__)))
                except:
                    pass
            try:
                with open(shortcut_path, "w", encoding="utf-8") as f:
                    f.write('@echo off\nstart "" "{}"\n'.format(current_bat))
                messagebox.showinfo("Autostart", "Autostart erfolgreich eingerichtet! Das HUD startet ab jetzt automatisch bei jedem Windows-Start.")
            except Exception as e:
                messagebox.showerror("Fehler", "Autostart Einrichtung fehlgeschlagen: {}".format(e))

if __name__ == "__main__":
    root = tk.Tk()
    app = DesktopHUD(root)
    root.mainloop()
